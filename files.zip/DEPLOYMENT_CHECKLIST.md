# ✅ DEPLOYMENT CHECKLIST - Najm Althuraya

Print this or keep it open while deploying!

---

## 🗂️ BEFORE YOU START

- [ ] Download the project file: `najm-althuraya-complete.tar.gz`
- [ ] Extract it on your computer
- [ ] Have your domain login ready (Zoho for najum-althuraya.com)
- [ ] Set aside 15 minutes of uninterrupted time

---

## 📝 STEP 1: DATABASE (Supabase) - 3 minutes

- [ ] Go to https://supabase.com
- [ ] Sign up / Create account
- [ ] Click "New Project"
- [ ] Project Name: `najm-althuraya`
- [ ] Database Password: ________________ (write it down!)
- [ ] Region: Choose Singapore or closest to UAE
- [ ] Click "Create new project"
- [ ] Wait 2-3 minutes for project creation

**Setup Database:**
- [ ] Click "SQL Editor" in left menu
- [ ] Click "New Query"
- [ ] Open file: `database/schema.sql` from extracted folder
- [ ] Copy ALL content from the file
- [ ] Paste in SQL Editor
- [ ] Click "RUN"
- [ ] Verify "Success. No rows returned" message

**Get Connection String:**
- [ ] Go to "Project Settings" (gear icon)
- [ ] Click "Database" in left sidebar
- [ ] Scroll to "Connection string" → "URI"
- [ ] Copy the connection string
- [ ] Replace [YOUR-PASSWORD] with your actual database password
- [ ] Write it here: _________________________________

---

## 🚂 STEP 2: BACKEND (Railway) - 3 minutes

- [ ] Go to https://railway.app
- [ ] Click "Login" → "Login with GitHub"
- [ ] Click "New Project"
- [ ] Click "Deploy from GitHub repo" (or "Empty Project")

**For GitHub method:**
- [ ] Upload your project to GitHub first
- [ ] Select the repository
- [ ] Railway will auto-deploy

**For manual/CLI method:**
- [ ] Install Railway CLI: `npm install -g @railway/cli`
- [ ] In terminal, go to backend folder: `cd backend`
- [ ] Run: `railway login`
- [ ] Run: `railway init`
- [ ] Run: `railway up`

**Set Environment Variables:**
- [ ] Click on your project in Railway
- [ ] Go to "Variables" tab
- [ ] Add variable: `DATABASE_URL` = (paste your Supabase connection string)
- [ ] Add variable: `JWT_SECRET` = `kj3h4k5jh34k5jh3k4j5h3k4j5h3k4j5h3k45jh` (or any random string)
- [ ] Add variable: `NODE_ENV` = `production`
- [ ] Add variable: `PORT` = `5000`
- [ ] Add variable: `CORS_ORIGIN` = `*`

**Get Backend URL:**
- [ ] Railway generates a URL like: `https://xxxxx.railway.app`
- [ ] Write it here: _________________________________
- [ ] Keep this URL - you need it for frontend!

---

## 🎨 STEP 3: FRONTEND (Vercel) - 3 minutes

- [ ] Go to https://vercel.com
- [ ] Click "Sign Up" → "Continue with GitHub"
- [ ] Click "Add New" → "Project"

**For GitHub method:**
- [ ] Import your Git repository
- [ ] Vercel auto-detects it's a Vite project

**For manual method:**
- [ ] In terminal, go to frontend folder: `cd frontend`
- [ ] Create `.env` file
- [ ] Add: `VITE_API_URL=https://your-railway-url.railway.app`
- [ ] Run: `npm install`
- [ ] Run: `npm run build`
- [ ] Drag `dist` folder to Vercel

**Set Environment Variable:**
- [ ] In Vercel project settings → "Environment Variables"
- [ ] Key: `VITE_API_URL`
- [ ] Value: (paste your Railway backend URL)
- [ ] Click "Save"

**Get Frontend URL:**
- [ ] Vercel gives you: `https://xxxxx.vercel.app`
- [ ] Test it - should show login page!

---

## 🌐 STEP 4: CONNECT DOMAIN - 5 minutes

**In Vercel:**
- [ ] Go to your project → "Settings" → "Domains"
- [ ] Click "Add"
- [ ] Enter: `najum-althuraya.com`
- [ ] Vercel shows DNS records you need to add

**In Zoho (or your domain provider):**
- [ ] Login to domain management
- [ ] Go to DNS settings
- [ ] Add records as shown by Vercel:
  - [ ] A Record: @ → (Vercel IP)
  - [ ] CNAME: www → (Vercel address)
- [ ] Save DNS changes
- [ ] Wait 5-60 minutes for DNS propagation

**Update CORS:**
- [ ] Go back to Railway
- [ ] Go to Variables
- [ ] Change `CORS_ORIGIN` from `*` to `https://najum-althuraya.com`
- [ ] Save

---

## 🔐 STEP 5: FIRST LOGIN - 1 minute

- [ ] Go to https://najum-althuraya.com (or your Vercel URL)
- [ ] Login with:
  - Email: `admin@najum-althuraya.com`
  - Password: `admin123`
- [ ] **IMMEDIATELY change the password!**
  - [ ] Click Settings or your profile
  - [ ] Change password to something secure
  - [ ] Write new password: ________________

---

## ⚙️ STEP 6: CUSTOMIZE SYSTEM - 2 minutes

- [ ] Click "Settings" icon (admin only sees this)
- [ ] Change "App Name" to whatever you like
- [ ] Choose your brand colors:
  - [ ] Primary Color: _________
  - [ ] Secondary Color: _________
- [ ] Set default language (Arabic or English)
- [ ] Click "Save"
- [ ] See changes apply immediately!

---

## 👥 STEP 7: ADD USERS - 2 minutes

- [ ] Go to "Users" page
- [ ] Click "Add User"
- [ ] Add your first employee:
  - [ ] Email: ________________
  - [ ] Full Name: ________________
  - [ ] Password: ________________ (they can change later)
  - [ ] Role: Employee
  - [ ] Phone: ________________ (optional)
- [ ] Click "Save"
- [ ] Repeat for supervisors (choose "Supervisor" role)

---

## 📝 STEP 8: TEST TRANSACTION - 2 minutes

- [ ] Go to "Transactions" page
- [ ] Click "New Transaction"
- [ ] Fill in:
  - [ ] Service Type: (e.g., "Passport Renewal")
  - [ ] Transaction Type: Select "New"
  - [ ] Client Name: "Test Client"
  - [ ] Passport/ID: "123456789"
  - [ ] Mobile: "+971501234567"
  - [ ] Status: "Pending"
  - [ ] Receive Date: (today)
  - [ ] Expected Delivery: (future date)
  - [ ] Notes: "Test transaction"
- [ ] Click "Create"
- [ ] Verify transaction appears in list with auto-generated number!

---

## ✅ VERIFICATION CHECKLIST

- [ ] Can access https://najum-althuraya.com
- [ ] Login works with admin account
- [ ] Admin password has been changed
- [ ] App name shows correctly (if you changed it)
- [ ] Colors match your selection (if you changed them)
- [ ] At least 1 user created
- [ ] At least 1 test transaction created
- [ ] Transaction has auto-generated number (TRX-YYYYMMDD-####)
- [ ] Can search for transaction
- [ ] Can edit transaction
- [ ] Language switching works (Arabic ↔ English)

---

## 🎉 YOU'RE DONE!

Your transaction management system is now:
- ✅ Fully deployed
- ✅ Accessible at your domain
- ✅ Ready for daily use
- ✅ Secure and production-ready

---

## 📞 QUICK TROUBLESHOOTING

**Can't login?**
→ Check Railway logs for backend errors
→ Verify database schema ran successfully in Supabase

**Page is blank?**
→ Check VITE_API_URL in Vercel points to Railway URL
→ Look at browser console (F12) for errors

**"CORS error" in browser?**
→ Make sure CORS_ORIGIN in Railway = your frontend domain

**Domain not working?**
→ DNS can take up to 24 hours (usually 5-60 minutes)
→ Try https://vercel-url.vercel.app first

---

## 📚 DOCUMENTATION

All guides are in your project folder:
- `README.md` - Full documentation
- `QUICK_START.md` - Fast setup guide
- `docs/DEPLOYMENT_GUIDE.md` - Detailed deployment
- `DELIVERY_SUMMARY.md` - What you received

---

## 🎯 NEXT STEPS

1. Train your staff on how to use the system
2. Add all users
3. Start adding real transactions
4. Monitor usage for first week
5. Adjust settings as needed

---

**Congratulations! Your system is live!** 🚀

_Keep this checklist for future reference or when deploying updates._
